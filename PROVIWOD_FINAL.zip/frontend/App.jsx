export default function App() {
  return <h1>PROVIWOD</h1>;
}